const http = require("http");
const fs = require("fs");

// Add logging to the CLI project by using eventLogging
// load the logEvents module
const logEvents = require("./logEvents");

// define/extend an EventEmitter class
const EventEmitter = require("events");
class MyEmitter extends EventEmitter {}

// initialize an new emitter object
const myEmitter = new MyEmitter();
// add the listener for the logEvent
myEmitter.on("log", (event, level, msg) => logEvents(event, level, msg));

function startServer() {
  const server = http.createServer((req, res) => {
    console.log(req.url, req.method);

    res.setHeader("Content-Type", "text/html");

    fs.readFile("./subfiles/views/test.html", (err, data) => {
      if (err) {
        console.log(err);
        res.end();
      } else {
        res.end(data);
      }
    });
  });
  server.listen(3000, "localhost", () => {
    console.log("listening for requests on port 3000");
  });
}
module.exports = { startServer };

const configjson = {
  name: "AppConfigCLI",
  version: "1.0.0",
  description: "The Command Line Interface (CLI) for the sprint1main.",
  main: "sprint1main.js",
  superuser: "adm1n",
  database: "exampledb",
};

const tokenjson = [
  {
    created: "1969-01-31 12:30:00",
    username: "username",
    email: "user@example.com",
    phone: "5556597890",
    token: "token",
    expires: "1969-02-03 12:30:00",
    confirmed: "tbd",
  },
];

const helptext = `

sprint1main <command> <option>

Usage:

sprint1main --help                            displays help
sprint1main init                              creates the directory structure and the default configuration and help files
sprint1main config --show                     displays a list of the current config settings
sprint1main config --reset                    resets the config file with default settings
sprint1main config --set <key> <value>        sets a specific config setting
sprint1main token --count                     displays a count of the tokens created
sprint1main token --list                      list all the usernames with tokens
sprint1main token --new <username>            generates a token for a given username, saves tokens to the json file
sprint1main token --upd p <username> <phone>  updates the json entry with phone number
sprint1main token --upd e <username> <email>  updates the json entry with email
sprint1main token --search u <username>       searches a token for a given username
sprint1main token --search e <email>          searches a token for a given email
sprint1main token --search p <phone>          searches a token for a given phone number

`;

const inittext = `

sprint1main init <command> <option>

Usage:

sprint1main init --all          creates the folder structure and config file
sprint1main init --mk           creates the folder structure
sprint1main init --cat          creates all the files with default settings

`;

const configtext = `

sprint1main <command> <option>

Usage:

sprint1main config --show     displays a list of the current config settings
sprint1main config --reset    resets the config file with default settings
sprint1main config --set      sets a specific config setting

`;

const tokentext = `

sprint1main <command> <option>

Usage:

sprint1main token --count                     displays a count of the tokens created
sprint1main token --list                      list all the usernames with tokens
sprint1main token --new <username>            generates a token for a given username, saves tokens to the json file
sprint1main token --upd p <username> <phone>  updates the json entry with phone number
sprint1main token --upd e <username> <email>  updates the json entry with email
sprint1main token --search u <username>       searches a token for a given username
sprint1main token --search e <email>          searches a token for a given email
sprint1main token --search p <phone>          searches a token for a given phone number

`;
const htmlIndex = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/skeleton/2.0.4/skeleton.min.css"
    />
    <title>Ian Collins Sprint1</title>
    <script type="text/javascript" src="../token.js"></script>
    <script>
      function makeToken(){
      var t = newToken(document.getElementById("token").value);
      // var t = document.getElementById("token").value;
      document.getElementById("displayToken").innerHTML = "Token: " + t;}
    </script>
  </head>
  <body>
    <h1>Create a token</h1>
    <hr />
    <p>
      <input type="text" id="token" value="" />
      <br />
      <button class="btn" onclick="makeToken()">Create</button>
      <div id="displayToken"></div>
    </p>
    
    
  </body>
</html>`;

module.exports = {
  configjson,
  tokenjson,
  helptext,
  inittext,
  configtext,
  tokentext,
  htmlIndex,
};

const http = require("http");
const fs = require("fs");
const { newToken } = require("./token");

// Add logging to the CLI project by using eventLogging
// load the logEvents module
const logEvents = require("./logEvents");

// define/extend an EventEmitter class
const EventEmitter = require("events");
class MyEmitter extends EventEmitter {}

// initialize an new emitter object
const myEmitter = new MyEmitter();
// add the listener for the logEvent
myEmitter.on("log", (event, level, msg) => logEvents(event, level, msg));

function makeToken() {
  var t = newToken(document.getElementById("token").value);
  // var t = document.getElementById("token").value;
  document.getElementById("displayToken").innerHTML = "Token: " + t;
}

function makeToken() {
  var t = newToken(document.getElementById("token").value);
  // var t = document.getElementById("token").value;
  document.getElementById("displayToken").innerHTML = "Token: " + t;
}

function startServer() {
  const server = http.createServer((req, res) => {
    console.log(req.url, req.method);

    res.setHeader("Content-Type", "text/html");

    fs.readFile("./subfiles/views/index.html", (err, data) => {
      if (err) {
        console.log(err);
        res.end();
      } else {
        res.end(data);
      }
    });
  });
  server.listen(3000, "localhost", () => {
    console.log("listening for requests on port 3000");
  });
}
module.exports = { startServer, makeToken };

const fs = require("fs");
const path = require("path");

// Add logging to the CLI project by using eventLogging
// load the logEvents module
const logEvents = require("./logEvents");

// define/extend an EventEmitter class
const EventEmitter = require("events");
class MyEmitter extends EventEmitter {}

// initialize an new emitter object
const myEmitter = new MyEmitter();
// add the listener for the logEvent
myEmitter.on("log", (event, level, msg) => logEvents(event, level, msg));

const {
  configjson,
  tokenjson,
  helptext,
  inittext,
  configtext,
  tokentext,
  htmlIndex,
} = require("./defaults");

function createFiles() {
  console.log("init.createFiles()");
  try {
    let configdata = JSON.stringify(configjson, null, 2);
    if (!fs.existsSync(path.join(__dirname, "/json/config.json"))) {
      fs.writeFile("./subfiles/json/config.json", configdata, (err) => {
        console.log("Data written to config.json file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "config.json successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "config.json already exists."
      );
    }
    let tokendata = JSON.stringify(tokenjson, null, 2);
    if (!fs.existsSync(path.join(__dirname, "/json/tokens.json"))) {
      fs.writeFile("./subfiles/json/tokens.json", tokendata, (err) => {
        console.log("Data written to token.json file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "tokens.json successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "token.json already exists."
      );
    }
    if (!fs.existsSync(path.join(__dirname, "/commands/help.txt"))) {
      fs.writeFile("./subfiles/commands/help.txt", helptext, (err) => {
        console.log("Data written to help.txt file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "help.txt successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "help.txt already exists."
      );
    }
    if (!fs.existsSync(path.join(__dirname, "/commands/init.txt"))) {
      fs.writeFile("./subfiles/commands/init.txt", inittext, (err) => {
        console.log("Data written to init.txt file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "init.txt successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "init.txt already exists."
      );
    }
    if (!fs.existsSync(path.join(__dirname, "/commands/config.txt"))) {
      fs.writeFile("./subfiles/commands/config.txt", configtext, (err) => {
        console.log("Data written to config.txt file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "config.txt successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "config.txt already exists."
      );
    }
    if (!fs.existsSync(path.join(__dirname, "/commands/token.txt"))) {
      fs.writeFile("./subfiles/commands/token.txt", tokentext, (err) => {
        console.log("Data written to token.txt file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "token.txt successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "token.txt already exists."
      );
    }
    if (!fs.existsSync(path.join(__dirname, "/views/index.html"))) {
      fs.writeFile("./subfiles/views/index.html", htmlIndex, (err) => {
        console.log("Data written to index.html file");
        myEmitter.emit(
          "log",
          "init.createFiles()",
          "INFO",
          "index.html successfully created."
        );
      });
    } else {
      myEmitter.emit(
        "log",
        "init.createFiles()",
        "INFO",
        "index.html already exists."
      );
    }
  } catch (err) {
    console.log(err);
  }
}

module.exports = { createFiles };

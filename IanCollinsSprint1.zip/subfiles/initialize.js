const fs = require("fs");
const { createFiles } = require("./createfiles");
const { createFolders } = require("./createfolders");

// Add logging to the CLI project by using eventLogging
// load the logEvents module
const logEvents = require("./logEvents");

// define/extend an EventEmitter class
const EventEmitter = require("events");
class MyEmitter extends EventEmitter {}

// initialize an new emitter object
const myEmitter = new MyEmitter();
// add the listener for the logEvent
myEmitter.on("log", (event, level, msg) => logEvents(event, level, msg));

const myArgs = process.argv.slice(2);

function initializeApp() {
  createFolders();
  createFiles();
}

module.exports = { initializeApp };

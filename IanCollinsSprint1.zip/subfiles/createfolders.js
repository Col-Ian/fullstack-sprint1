const fs = require("fs");
const fsPromises = require("fs").promises;
const path = require("path");

// Add logging to the CLI project by using eventLogging
// load the logEvents module
const logEvents = require("./logEvents");

// define/extend an EventEmitter class
const EventEmitter = require("events");
class MyEmitter extends EventEmitter {}

// initialize an new emitter object
const myEmitter = new MyEmitter();
// add the listener for the logEvent
myEmitter.on("log", (event, level, msg) => logEvents(event, level, msg));

const folders = ["commands", "json", "logs", "views"];

function createFolders() {
  // if (DEBUG)
  console.log("init.createFolders()");
  let createCount = 0;
  folders.forEach((e) => {
    // if (DEBUG) console.log(element);
    try {
      if (!fs.existsSync(path.join(__dirname, e))) {
        fsPromises.mkdir(path.join(__dirname, e));
        createCount++;
      } else {
        myEmitter.emit(
          "log",
          "init.createFolders()",
          "INFO",
          `${e} folder already exists`
        );
      }
    } catch (err) {
      console.log(err);
    }
  });
  if (createCount === 0) {
    // if (DEBUG)
    console.log("All folders already exist.");
    myEmitter.emit(
      "log",
      "init.createFolders()",
      "INFO",
      `All folders already exists`
    );
  } else if (createCount <= folders.length) {
    // if (DEBUG)
    console.log(
      createCount + " of " + folders.length + " folders were created."
    );
    myEmitter.emit(
      "log",
      "init.createFolders()",
      "INFO",
      `${createCount} of ${folders.length} folders were created.`
    );
  } else {
    // if (DEBUG)
    console.log("All folders successfully created.");
    myEmitter.emit(
      "log",
      "init.createFolders()",
      "INFO",
      `All folders successfully created.`
    );
  }
}

module.exports = { createFolders };

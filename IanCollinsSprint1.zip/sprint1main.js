/*
Stories:
  •As a system administrator I would like a command line interface(CLI)to initialize the application to build the required directory structure and add the default configuration and help files. (done)
  •As a system administrator I would like the CLI to provide a status for the initialization and configuration.(done)
  •As a system administrator I would like the CLI to provide a view of the current configuration file(s). (done)
  •As a system administrator I would like the CLI to provide the ability to update the configuration file with new values. (done)
  •As a system administrator I would like the CLI to provide the ability to reset the configuration file back to its original state. (done)
  •As a helpdesk employee, I would like the CLI to provide the ability to generate a user token based on an end users username. This token would be the same as presented to the user via the end user self service web form. (done)
  •As a new end user I would like a web form that allows me to enter my username and after pressing submit receive a token I would use to confirm my new membership. (WIP)
  •(Note: thistoken should be sent to the new user via email or SMS.(At this timeKeyin does nothave eitheran outbound email or SMSserver available for this development testing. We will stay with using the web form)
*/
global.DEBUG = false;
const fs = require("fs");
const { configApp } = require("./subfiles/config");
const { initializeApp } = require("./subfiles/initialize");
const { startServer } = require("./subfiles/server");
// const { startServer } = require("./subfiles/test");
const { tokenApp } = require("./subfiles/token");
const myArgs = process.argv.slice(2);
switch (myArgs[0]) {
  case "init":
  case "i":
    console.log("initializing");
    initializeApp();
    break;
  case "config":
  case "c":
    configApp();
    break;
  case "token":
  case "t":
    tokenApp();
    break;
  case "web":
  case "w":
    startServer();
    break;
  case "--help":
  case "--h":
  default:
    fs.readFile("./help.txt", (error, data) => {
      if (error) throw error;
      console.log(data.toString());
    });
}
